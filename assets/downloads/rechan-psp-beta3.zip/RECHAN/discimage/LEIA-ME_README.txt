Copie aqui a imagem do seu disco de Jackie Chan Stuntmaster (NTSC-U,
SLUS-00684, .bin ou .iso). Depois da extração ela pode ser apagada.

Copy the image of your Jackie Chan Stuntmaster disc (NTSC-U, SLUS-00684,
.bin or .iso) here. It can be deleted after the extraction.
